import { Component ,OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators} from '@angular/forms';
 
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  handsonform: any;
  constructor(){}

  ngOnInit() {

  this.handsonform = new FormGroup({
    'AssociateName' : new FormControl(null, [Validators.minLength(5), Validators.maxLength(30) ,Validators.pattern('^[a-z A-Z ]*$')]   ),
    'AssociateId' : new FormControl(null,  [Validators.minLength(6), Validators.maxLength(6) ,Validators.pattern('^[0-9 ]*$')   ]  ),
    'ProjectID' :new FormControl(null, [Validators.minLength(12), Validators.maxLength(12) ,Validators.pattern('^[a-zA-Z0-9 ]*$') ] ),
    'Offshore':new FormControl('',Validators.required),
    'Onshore':new FormControl('',Validators.required),
    
    'HTML5':new FormControl(''),
    'SASS':new FormControl(''),
    'ES5':new FormControl(''),
    'BOOTSTRAP':new FormControl(''),


    'ANGULAR':new FormControl(''),
    'REACTJS':new FormControl(''),
    'VEUJS':new FormControl(''),
    'TYPESCRIPT':new FormControl(''),


    'EXPRESSJS':new FormControl(''),
    'NODEJS':new FormControl(''),
    'MONGODB':new FormControl(''),


    'UploadProfile':new FormControl(null, Validators.required),
     
    'Comments' : new FormControl(null, Validators.required)
  });
  }

  clicksub() {
    console.log(this.handsonform.value);
    
  }
  clickreset(){
    this.handsonform.reset();
  }

  getControls(){
    return this.handsonform.controls;
  }
  get AssociateName() {
    return this.handsonform.get('AssociateName');
  }
  get AssociateId() {
    return this.handsonform.get('AssociateId');
  }
  get ProjectID() {
    return this.handsonform.get('ProjectID');
  }
  get Offshore(){
    return this.handsonform.get('Offshore');
  }
  get Onshore(){
    return this.handsonform.get('Onshore');
  }

  get UploadProfile() {
    return this.handsonform.get('UploadProfile');
  }

  get Comments() {
    return this.handsonform.get('Comments');
  }
  
  get HTML5() {
    return this.handsonform.get('HTML5');
  }

  get SASS() {
    return this.handsonform.get('SASS');
  }
  
  get ES5() {
    return this.handsonform.get('ES5');
  }

  get BOOTSTRAP() {
    return this.handsonform.get('BOOTSTRAP');
  }

  get ANGULAR() {
    return this.handsonform.get('ANGULAR');
  }
  get REACTJS() {
    return this.handsonform.get('REACTJS');
  }
  get VEUJS() {
    return this.handsonform.get('VEUJS');
  }
  get TYPESCRIPT() {
    return this.handsonform.get('TYPESCRIPT');
  }
  get EXPRESSJS() {
    return this.handsonform.get('EXPRESSJS');
  }
  get NODEJS() {
    return this.handsonform.get('NODEJS');
  }
  get MONGODB() {
    return this.handsonform.get('MONGODB');
  }




}